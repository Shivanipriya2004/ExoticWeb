# Exotic Web

A Pen created on CodePen.io. Original URL: [https://codepen.io/SHIVANIPRIYA-P/pen/qBvgRGV](https://codepen.io/SHIVANIPRIYA-P/pen/qBvgRGV).

